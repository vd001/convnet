from collections import defaultdict as dd
from scipy import sparse as sp
from scipy.sparse import csr_matrix
from scipy.sparse import vstack
from sklearn.ensemble import IsolationForest
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
import argparse
import copy
import cPickle as cpkl
import numpy as np
import os
import sys
import tensorflow as tf

class model(object):
  """The SEANO model for semi-supervised attributed network embedding."""
  def __init__(self, args, data, session):
    self.inductive = args.inductive
    self.embedding_size = args.embedding_size
    self.learning_rate = args.learning_rate 
    self.batch_size = args.batch_size
    self.neg_samp = args.neg_samp
    
    self.window_size = args.window_size
    self.path_size = args.path_size
    
    self.g_learning_rate = args.g_learning_rate
    self.g_batch_size = args.g_batch_size # rnd walk
    self.g_sample_size = args.g_sample_size # label proximity
    
    self.data = data
    self.all_x, self.all_y, self.label_x, self.label_y, self.neigh_x = (data.all_x, data.all_y, data.label_x, data.label_y, data.neigh_x)
    self.can_visit_during_train = data.can_visit_during_train
    self.graph = data.graph
    # In the inductive case, testing nodes are not accessible during training.
    self.vertices_num = data.all_x.shape[0] 
    self.attributes_num = data.all_x.shape[1]
    self.labels_num = data.all_y.shape[1]

    self.model_dic = dict()
    
    self.supervised_inst_generator = self.supervised_instance_iter()
    self.unsupervised_label_contx_generator = self.unsupervised_label_context_iter()
    self.unsupervised_graph_contx_generator = self.unsupervised_graph_context_iter()
    self.session = session
    self.build_tf_graph()


  def build_tf_graph(self):
    """Create the TensorFlow graph. """
    input_node_idx = tf.placeholder(tf.int32, shape=[None], name="graph_input_node_idx")

    input_attr = tf.placeholder(tf.float32, shape=[None, self.attributes_num], name="input_attr")
    neigh_attr = tf.placeholder(tf.float32, shape=[None, self.attributes_num], name="neigh_attr")
    truth_label = tf.placeholder(tf.int32, shape=[None, self.labels_num], name="truth_label")
    # this should not be [None, 1] due to the format of embedding lookup.
    graph_context = tf.placeholder(tf.int32, shape=[None], name="graph_context") 
    pos_or_neg = tf.placeholder(tf.float32, shape=[None], name="pos_or_neg")
    episilon = tf.constant(1e-6)

    W = tf.get_variable("W", shape=(self.attributes_num, self.embedding_size),
                        initializer=tf.contrib.layers.xavier_initializer())
    b = tf.Variable(tf.random_uniform([self.embedding_size], -1.0, 1.0)) 
    embed_layer = tf.nn.relu(tf.matmul(input_attr, W) + b)
    neigh_embed_layer = tf.nn.relu(tf.matmul(neigh_attr, W) + b)

    # aggregation weight lambda = \sigma(alpha)
    # 0.0: even distribution of weight. inf: no weight on the neighbor.
    alpha = tf.get_variable("alpha", shape=[self.vertices_num, 1], initializer=tf.zeros_initializer()) 
    input_attr_wgt = tf.sigmoid(tf.nn.embedding_lookup(alpha, input_node_idx)) # this is lambda
    joint_embed_layer = tf.multiply(input_attr_wgt, embed_layer) + tf.multiply((1-input_attr_wgt), neigh_embed_layer)

    # l_2 layer
    hid_dim = self.labels_num
    W_2 = tf.get_variable("W_2", shape=(self.embedding_size, hid_dim), 
                          initializer=tf.contrib.layers.xavier_initializer())
    b_2 = tf.Variable(tf.random_uniform([hid_dim], -1.0, 1.0))
    output_logits = tf.matmul(joint_embed_layer, W_2) + b_2

    # note the loss function is on the sum...
    loss_supervised = tf.reduce_sum(tf.nn.softmax_cross_entropy_with_logits(logits=output_logits, labels=truth_label))
    optimizer_supervised = tf.train.GradientDescentOptimizer(learning_rate=self.learning_rate).minimize(loss_supervised) 

    out_embed_layer = tf.Variable(tf.random_normal([self.vertices_num, self.embedding_size], stddev=0.01))
    out_embed_vecs = tf.nn.embedding_lookup(out_embed_layer, graph_context) # lookup from output

    ele_wise_prod = tf.multiply(joint_embed_layer, out_embed_vecs)
    loss_unsupervised = -tf.reduce_sum(tf.log(tf.sigmoid(tf.reduce_sum(ele_wise_prod, axis=1) * pos_or_neg) + episilon))
    optimizer_unsupervised = tf.train.GradientDescentOptimizer(learning_rate=self.g_learning_rate).minimize(loss_unsupervised)

    pred_label = output_logits

    self.model_dic['input'] = input_attr
    self.model_dic['neigh'] = neigh_attr
    self.model_dic['truth_label'] = truth_label
    self.model_dic['truth_context'] = graph_context
    self.model_dic['pos_or_neg'] = pos_or_neg
    self.model_dic['pred_label'] = pred_label # logits for the label
    self.model_dic['loss_s'] = loss_supervised
    self.model_dic['opt_s'] = optimizer_supervised
    self.model_dic['loss_u'] = loss_unsupervised
    self.model_dic['opt_u'] = optimizer_unsupervised
    self.model_dic['embeddings'] = joint_embed_layer
    self.model_dic['neigh_based_scores'] = input_attr_wgt # learnt outlier scores
    self.model_dic['input_attr_wgt'] = input_attr_wgt
    self.model_dic['input_node_idx'] = input_node_idx

    init = tf.global_variables_initializer()
    self.session.run(init)


  def supervised_train_step(self):
    """Supervised training step. """
    batch_x, batch_y, batch_idx, batch_neigh, input_idx = next(self.supervised_inst_generator)
    if not np.all(self.can_visit_during_train[input_idx]):
      print "error"
    _, loss = self.session.run([self.model_dic['opt_s'], 
                                self.model_dic['loss_s']],
                                feed_dict={self.model_dic['input']: batch_x,
                                           self.model_dic['neigh']: batch_neigh, 
                                           self.model_dic['truth_label']: batch_y,
                                           self.model_dic['input_node_idx']: input_idx})
    return loss


  def unsupervised_train_step(self, is_graph_context=False, is_label_context=False):
    """Unsupervised training step."""
    if is_graph_context:
      batch_x, batch_gy, batch_pos_or_neg, batch_idx, batch_neigh, input_idx = next(self.unsupervised_graph_contx_generator)
      if not np.all(self.can_visit_during_train[input_idx]): # ensure testing data not used for training in inductive learning.
        print "error graph context"
    elif is_label_context:
      batch_x, batch_gy, batch_pos_or_neg, batch_idx, batch_neigh, input_idx = next(self.unsupervised_label_contx_generator)
      if not np.all(self.can_visit_during_train[input_idx]):
        print "error label context"
    _, loss = self.session.run([self.model_dic['opt_u'],
                                self.model_dic['loss_u']], 
                                feed_dict={self.model_dic['input']: batch_x, 
                                           self.model_dic['neigh']: batch_neigh,
                                           self.model_dic['truth_context']: batch_gy, 
                                           self.model_dic['pos_or_neg']: batch_pos_or_neg,
                                           self.model_dic['input_node_idx']: input_idx})
    return loss


  def eval(self, is_train=False, is_val=False, is_test_all=False, is_test_1k=False): # only one of them is True
    """Evaluation using different datasets."""
    eval_x, eval_y  = [None] * 2
    if is_train:
      eval_x = self.data.label_x
      eval_y = self.data.label_y
      eval_neigh_x = self.data.label_neigh_x
      input_idx = self.data.labeled_idx
    elif is_val:
      eval_x = self.data.val_x
      eval_y = self.data.val_y
      eval_neigh_x = self.data.val_neigh_x
      input_idx = self.data.val_idx
    elif is_test_all:
      eval_x = self.data.test_x_all
      eval_y = self.data.test_y_all
      eval_neigh_x = self.data.test_neigh_x_all
      input_idx = self.data.remaining_idx
    elif is_test_1k:
      eval_x = self.data.test_x_1k
      eval_y = self.data.test_y_1k
      eval_neigh_x = self.data.test_neigh_x_1k
      input_idx = self.data.tx_idx

    if eval_x is not None and eval_y is not None:
      pred_labels, = self.session.run([self.model_dic['pred_label']], feed_dict={self.model_dic['input']: eval_x, 
                                                                                 self.model_dic['neigh']: eval_neigh_x,
                                                                                 self.model_dic['input_node_idx']: input_idx}) 
      truth_labels = np.argmax(eval_y, axis=1)
      pred_labels = np.argmax(pred_labels, axis=1)
      if self.labels_num == 2:
        return (accuracy_score(truth_labels, pred_labels), precision_score(truth_labels, pred_labels), 
          recall_score(truth_labels, pred_labels), f1_score(truth_labels, pred_labels), roc_auc_score(truth_labels, pred_labels))
      else:
        return (accuracy_score(truth_labels, pred_labels), 
          f1_score(truth_labels, pred_labels, average="macro"), f1_score(truth_labels, pred_labels, average="weighted"))

  def store_useful_information(self):
    """Store useful information, such as embeddings, outlier scores, after the model finish training."""
    embeddings, neigh_based_scores = self.session.run([self.model_dic['embeddings'], self.model_dic['neigh_based_scores']], 
        feed_dict={self.model_dic['input']: self.all_x, 
                   self.model_dic['neigh']: self.neigh_x, 
                   self.model_dic['input_node_idx']: range(self.all_x.shape[0])})
    if not os.path.exists(os.path.dirname(self.data.output_str)):
      os.makedirs(os.path.dirname(self.data.output_str))

    cpkl.dump(embeddings, open(self.data.output_str + ".embed", "wb"))
    cpkl.dump(zip(range(self.all_x.shape[0]), neigh_based_scores), open(self.data.output_str + ".outlier_score", "wb"))

    pred_labels, = self.session.run([self.model_dic['pred_label']], feed_dict={self.model_dic['input']: self.all_x, 
    									       self.model_dic['neigh']: self.neigh_x,
                                                                               self.model_dic['input_node_idx']: range(self.all_x.shape[0])})
    pred_labels = np.argmax(pred_labels, axis=1)
    cpkl.dump(pred_labels, open(self.data.output_str +".pred_label", "wb"))

  def supervised_instance_iter(self):
    """Iterator for generating instances for supervised training.
    Do not need to worry about inductive as this part of data will always be accessible (labeled data)."""
    permuted_idx = np.array(np.random.permutation(self.data.labeled_idx), dtype = np.int32)
    while True:
      selected_idx = np.random.choice(permuted_idx, self.batch_size, replace=True)
      yield self.all_x[selected_idx], self.all_y[selected_idx], selected_idx, self.neigh_x[selected_idx], selected_idx

  def unsupervised_label_context_iter(self):
    """Generating batched instances for label context (unsupervised). 
    Do not need to worry about inductive as this part of data will always be accessible (labeled data)."""
    label2idx, not_label2idx = dd(list), dd(list)
    squeeze_y = np.argmax(self.label_y, axis=1)
    for i in range(self.label_x.shape[0]):
      label = squeeze_y[i]
      label2idx[label].append(i)
      for j in range(self.labels_num):
        if j is not label:
          not_label2idx[j].append(i)

    while True:
      context_pairs, pos_or_neg = [], []
      cnt = 0
      while cnt < self.g_sample_size:
        input_idx = np.random.randint(0, self.label_x.shape[0] - 1)
        label = squeeze_y[input_idx]
        if len(label2idx) == 1: continue
        target_idx = np.random.choice(label2idx[label])
        context_pairs.append([input_idx, target_idx])
        pos_or_neg.append(1.0)
        for _ in range(self.neg_samp):
          context_pairs.append([input_idx, np.random.choice(not_label2idx[label])])
          pos_or_neg.append(-1.0)
        cnt += 1
      context_pairs = np.array(context_pairs, dtype = np.int32)
      pos_or_neg = np.array(pos_or_neg, dtype = np.float32) 
      input_idx_var = context_pairs[:, 0]
      yield self.all_x[input_idx_var], context_pairs[:, 1], pos_or_neg, input_idx_var, self.neigh_x[input_idx_var], input_idx_var
    

  def gen_rnd_walk_pairs(self):
    print "Generate random walks..."
    all_pairs = []
    permuted_idx = np.random.permutation(self.vertices_num)
    # Only sample some idx if # nodes is too large.
    if (len(permuted_idx) > 10000):
      permuted_idx = np.random.choice(permuted_idx, 10000, replace=False)
      print "Randomly selected src nodes for random walk..."
    for start_idx in permuted_idx: # if this consumes too much memory, it can be easily adjust by getting the first k elements.
      if start_idx not in self.graph or len(self.graph[start_idx]) == 0: continue
      path = [start_idx]
      for _ in range(self.path_size): 
        if path[-1] in self.graph and self.can_visit_during_train[path[-1]]: # make sure the rnd walk will not visited unseen nodes.
          path.append(np.random.choice(self.graph[path[-1]]))
      if not self.can_visit_during_train[path[-1]]:
        del path[-1]
      for l in range(len(path)):
        for m in range(l - self.window_size, l + self.window_size + 1):
          if m < 0 or m >= len(path): 
            continue
          all_pairs.append([path[l], path[m]])
    return np.random.permutation(all_pairs)

  def unsupervised_graph_context_iter(self):
    """Unsupervised graph context iterator."""
    rnd_walk_save_file = "./data/" + self.data.dataset + ".rnd_walks.npy"
    if self.inductive: 
      rnd_walk_save_file = "./data/" + self.data.dataset + ".rnd_walks_induc.npy"

    save_walks = np.array([], dtype=np.int32).reshape(0,2)
    if os.path.exists(rnd_walk_save_file):
      save_walks = np.load(rnd_walk_save_file)
    
    all_pairs = save_walks
    new_walks = np.array([], dtype=np.int32).reshape(0,2) # buffer storage
    # semi-random setting to cap the max number of pairs, after which point the rnd walks will not be newly generated.
    max_num_pairs = max(10000000, self.vertices_num * 100)
    while True:
      if len (all_pairs) == 0:
        if len(save_walks) >= max_num_pairs: # enough rnd walks, reuse them.
          all_pairs = save_walks
        else:
          all_pairs = self.gen_rnd_walk_pairs()
          print "newly generated rnd walks " + str(all_pairs.shape)
          new_walks = np.concatenate((new_walks, all_pairs), axis=0) # save the new walks to buffer
          if len(new_walks) >= 10000: # buffer full.
            save_walks = np.concatenate((save_walks, new_walks), axis=0)
            np.save(rnd_walk_save_file, save_walks)
            print "Successfully save the walks..."
            new_walks = np.array([], dtype=np.int32).reshape(0,2)
      i = 0
      j = i + self.g_batch_size
      while j < len(all_pairs):
        pos_or_neg = np.array([1.0] * self.g_batch_size + [-1.0] * self.g_batch_size * self.neg_samp, dtype=np.float32)
        context_pairs = np.zeros((self.g_batch_size + self.g_batch_size * self.neg_samp, 2), dtype=np.int32)
        context_pairs[:self.g_batch_size, :] = all_pairs[i:j, :]
        context_pairs[self.g_batch_size:, 0] = np.repeat(all_pairs[i:j, 0], self.neg_samp)
        context_pairs[self.g_batch_size:, 1] = np.random.randint(0, self.vertices_num-1, self.g_batch_size * self.neg_samp)
        input_idx_var = context_pairs[:, 0]
        yield self.all_x[input_idx_var], context_pairs[:, 1], pos_or_neg, input_idx_var, self.neigh_x[input_idx_var], input_idx_var
        i = j
        j = i + self.g_batch_size
      all_pairs = []
