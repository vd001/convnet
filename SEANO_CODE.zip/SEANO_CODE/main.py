#!/usr/bin/env python
from scipy import sparse as sp
import argparse
import cPickle
import numpy as np
import os
import sys
import tensorflow as tf
import time

from SEANO_model import model
from utils import data
from utils import format_metrics_str
from utils import str2bool

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', help = 'the name of the dataset', type = str, default = 'cora')
parser.add_argument('--inductive', help = 'inductive or not', type=str2bool, default= 'False' , const=True, nargs='?')
parser.add_argument('--learning_rate', help = 'learning rate for supervised loss', type = float, default = 1e-2)
parser.add_argument('--g_learning_rate', help = 'learning rate for unsupervised loss', type = float, default = 1e-2)

parser.add_argument('--embedding_size', help = 'embedding dimensions', type = int, default = 50)
parser.add_argument('--window_size', help = 'window size in random walk sequences', type = int, default = 3)
parser.add_argument('--path_size', help = 'length of random walk sequences', type = int, default = 10)
parser.add_argument('--batch_size', help = 'batch size for supervised loss', type = int, default = 200)
parser.add_argument('--g_batch_size', help = 'batch size for graph context loss', type = int, default = 4) # this is usually smaller than g_gample_size
parser.add_argument('--g_sample_size', help = 'batch size for label context loss', type = int, default = 128)
parser.add_argument('--neg_samp', help = 'negative sampling rate', type = int, default = 6)
parser.add_argument('--max_iter', help = 'max iterations of training', type = int, default = 1e4) # reduce this number if you just want to get some quick results. Increasing this number usually leads to better results but takes more time.

args = parser.parse_args()
print args

data = data(args)
max_accuracy = 0.1
# for saving tensorflow model
save_dir = "./saved_model/" + args.dataset + "/"
if not os.path.exists(save_dir):
  os.makedirs(save_dir)
save_path = save_dir + "tmp.best.ckpt"

max_accu_iter = 0
prev_accu = 0.0
print_every_k_iters = 500
start_time = time.time()

with tf.Graph().as_default(), tf.Session() as session:
  model = model(args, data, session)
  saver = tf.train.Saver()
  writer = tf.summary.FileWriter('./saved_model/', session.graph)
  iter_cnt = 0
  while True:
    iter_cnt += 1
    curr_loss_s, curr_loss_u_1, curr_loss_u_2 = (0.0, 0.0, 0.0)

    curr_loss_u_1 = model.unsupervised_train_step(is_graph_context=True) # unsupervised training using network context.
    curr_loss_u_2 = model.unsupervised_train_step(is_label_context=True) # unsupervised training using label context.
    curr_loss_s = model.supervised_train_step() # supervised training.

    # Use the validation dataset for tuning the parameter.
    accuracy = model.eval(is_val=True)[0]
    if accuracy > max_accuracy:
      max_accuracy = accuracy
      max_accu_iter = iter_cnt
      saver.save(session, save_path)

    if iter_cnt%print_every_k_iters == 0: # for printing info.
      curr_loss = curr_loss_s + curr_loss_u_1 + curr_loss_u_2
      print iter_cnt, "loss=", curr_loss, format_metrics_str(model.eval(is_val=True)), "time = "+ str(int(time.time()-start_time)) + " s"
      if iter_cnt%(10*print_every_k_iters) == 0:
        print "Max accu on 1k test: " + str(format_metrics_str(model.eval(is_test_1k=True)))

    # For early stopping, the max_accu is too far away from current model, which means the training has converged.
    if iter_cnt > args.max_iter or iter_cnt - max_accu_iter >= 0.2*args.max_iter:
      print "Model has converged. Early stopping... (max_accu_iter/curr_iter: " + str(max_accu_iter) + "/" + str(iter_cnt)
      break

  # restore the best model if it has been stored.
  saver.restore(session, save_path)
  model.store_useful_information()

  print "max_accuracy", max_accuracy
  print "Performance on validation dataset", format_metrics_str(model.eval(is_val=True))
  print "Performance on 1k_test dataset", format_metrics_str(model.eval(is_test_1k=True))
#  print "Performance on all_test dataset", format_metrics_str(model.eval(is_test_all=True))
  writer.close()
