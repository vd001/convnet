from scipy.sparse import csr_matrix
from scipy.sparse import vstack
import cPickle
import numpy as np
import sys

class data(object):
  def __init__(self, args):
    self.dataset = ""
    self.all_x = None
    self.all_y = None
    self.label_x = None # training data containing label.
    self.label_y = None
    self.val_x = None # will be used for parameter tuning.
    self.val_y = None
    self.test_x_1k = None # will be used for performance evaluation.
    self.test_y_1k = None
    self.test_x_all = None
    self.test_y_all = None
    self.graph = None
    self.can_visit_during_train = None
    self.labeled_idx = None
    self.val_idx = None
    self.tx_idx = None
    self.load_data_from_disk(args)

  def load_data_from_disk(self, args):
    print "Loading the data from disk..."
    file_names = ["X", "Y", "graph", "labeled.index", "val.index", "test.index"]
    objs = []
    dataset_prefix = args.dataset
    self.dataset = args.dataset
    input_path = "./data"
    for i in range(len(file_names)):
      objs.append(cPickle.load(open("{}/{}.{}".format(input_path, dataset_prefix, file_names[i]))))
    all_x, all_y, graph, labeled_idx, val_idx, tx_idx = tuple(objs)

    # mask for distinguishing inductive learning. Mark the instance/node as zero, if it should
    # not be visited during training.
    can_visit_during_train = np.array([True] * all_x.shape[0])
    self.output_str = "./output/"+dataset_prefix

    if args.inductive: 
      self.output_str = self.output_str + "_ind"
      # In the case of inductive, the tx (test_x_1k) will not be in the training and only used for testing.
      can_visit_during_train[tx_idx] = False

    all_x = all_x.todense()

    print "Loading is done."
    self.all_x = all_x
    self.all_y = all_y
    self.label_x = all_x[labeled_idx] # the labeled data is the first 20 * k samples in all_x
    self.label_y = all_y[labeled_idx]
    self.val_x = all_x[val_idx] 
    self.val_y = all_y[val_idx]
    self.test_x_1k = all_x[tx_idx]
    self.test_y_1k = all_y[tx_idx]
    # this is only valid for transductive learning.
    remaining_idx = sorted(list(set(range(0, all_x.shape[0])) - set(labeled_idx)))
    self.remaining_idx = remaining_idx
    self.test_x_all = all_x[remaining_idx]
    self.test_y_all = all_y[remaining_idx]
    self.graph = graph
    self.can_visit_during_train = can_visit_during_train
    self.labeled_idx = labeled_idx
    self.val_idx = val_idx
    self.tx_idx = tx_idx
    self.neigh_x = self.compute_neigh()
    self.val_neigh_x = self.neigh_x[val_idx]
    self.test_neigh_x_1k = self.neigh_x[tx_idx]
    self.test_neigh_x_all = self.neigh_x[remaining_idx]
    self.label_neigh_x = self.neigh_x[labeled_idx]


  def compute_neigh(self):
    neigh_attr = [None] * self.all_x.shape[0]

    for i in range(self.all_x.shape[0]):
        if self.can_visit_during_train[i]: # Can be visited during training. It will exclude testing nodes in inductive learning.
            neigh = np.array(self.graph[i])[np.where(self.can_visit_during_train[self.graph[i]])[0]]
        else: # this must be the testing node during inference, so it should include all the neighbors.
            neigh = self.graph[i]
	if len(neigh) > 0:
	    neigh_attr[i] = np.mean(self.all_x[neigh], axis=0)
	else:
	    neigh_attr[i] = self.all_x[i]
    return np.array(neigh_attr).reshape(self.all_x.shape)

# formulate the output string.
def format_metrics_str(metric_values):
  return ["{0:.4f}".format(ele) for ele in metric_values]

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
